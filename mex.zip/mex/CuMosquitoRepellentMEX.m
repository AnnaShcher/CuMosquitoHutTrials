function [ in, dead, trap, fed, unf_dead ] = ...
CuMosquitoRepellentMEX(repetitions, experiments, exp_params)
%CUMOSQUITOREPELLENTMEX Summary of this function goes here
%   Detailed explanation goes here

[in, dead, trap, fed, unf_dead] = CuMosquitoRepellent(repetitions, experiments, exp_params);

end

